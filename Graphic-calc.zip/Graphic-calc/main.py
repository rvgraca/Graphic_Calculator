import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
import numpy as np
import sympy as sp
from sympy import symbols, summation, sympify, diff, integrate, pi
import customtkinter as ctk
from PIL import Image, ImageTk, ImageSequence
import sys
import io
import re
import imageio
import os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')


screen_size = "1280x720"
icon_calculator_address = "./Main/assets/calculadora_icon.png"
icon_calculator2_address = "./Main/assets/calculator-solid.png"
bin_icon_address = "./Main/assets/bin_icon.png"
refresh_icon_address = "./Main/assets/refresh_icon.png"

delete_calculator_address = "./Main/assets/delete_calculator.png"
graph_address = "./Main/assets/graph.png"
gamma_address = "./Main/assets/gamma.png"
sqrt_address = "./Main/assets/sqrt.png"
tick_address = "./Main/assets/tick.png"
summation_address = "./Main/assets/summation.png"

white_screen = "#FAFCFC"
barra_izquierda = "#E7EBEA"
gris_barra_izquierda = "#B0B8B5"
gris_oscuro_barra_izquierda = "#8B9390"
frame_verde1 = "#10E396"
frame_verde2 = "#05B46A"
frame_verde3 = "#005527"



class BasicCalculator(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg='blue')
        self.grid(sticky="nsew")  # Asegura que el frame ocupe el espacio asignado en el grid
        self.columnconfigure(0, weight=4)  # 10%
        self.columnconfigure(1, weight=12)  # 60%
        self.rowconfigure(0, weight=1)
        self.create_widgets()

    def create_widgets(self):
        # Crear el control_bar como un Frame propio
        self.control_bar = tk.Frame(self, bg='violet')
        self.control_bar.grid(column=0, row=0, sticky="nsew")

        # Configurar grid en control_bar
        self.control_bar.columnconfigure(0, weight=1)

        # Configuración de los widgets dentro de control_bar
        ttk.Label(self.control_bar, text="Enter expression:").grid(sticky="ew")
        self.entry_expression = ttk.Entry(self.control_bar, width=30)
        self.entry_expression.grid(sticky="ew")
        ttk.Button(self.control_bar, text="Calculate", command=self.calculate_expression).grid(sticky="ew")
        self.label_result = ttk.Label(self.control_bar, text="Result:")
        self.label_result.grid(sticky="ew")

    def calculate_expression(self):
        try:
            result = eval(self.entry_expression.get())
            self.label_result.config(text=f"Result: {result}")
        except Exception as e:
            messagebox.showerror("Error", "Invalid expression")
            print(e)

class GraphicalCalculator(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.grid(sticky="nsew")  # Asegura que el frame ocupe el espacio asignado en el grid
        self.columnconfigure(0, weight=6)  # 10%
        self.columnconfigure(1, weight=12)  # 60%
        self.rowconfigure(0, weight=1)
        self.rad_mode = True
        self.deg_mode = False
        self.shift_active = False
        self.ans = []
        self.ans.append("0")
        self.x = symbols('x')

        img_refresh_icon = Image.open(refresh_icon_address)
        img_bin_icon = Image.open(bin_icon_address)

        img_bin_icon = img_bin_icon.resize((25,  int((float(img_bin_icon.size[1]) * float((25 / float(img_bin_icon.size[0])))))))
        self.photo_bin = ctk.CTkImage(img_bin_icon)

        img_refresh_icon = img_refresh_icon.resize((25,  int((float(img_refresh_icon.size[1]) * float((25 / float(img_refresh_icon.size[0])))))))
        self.photo_refresh = ctk.CTkImage(img_refresh_icon)

        style = ttk.Style()
        style.configure("CustomCheckbutton.TCheckbutton", background=gris_barra_izquierda, focus_outline = "none")

        self.create_widgets()

    def create_widgets(self):
        self.function_dict = {
            'sin': 'np.sin',
            'cos': 'np.cos',
            'tan': 'np.tan',
            'log': 'np.log',
            'exp': 'np.exp',
            'sqrt': 'np.sqrt',
            'Γ': 'gamma', 
            'sinh': 'np.sinh',
            'cosh': 'np.cosh',
            'tanh': 'np.tanh',
            'arcsin': 'np.arcsin',
            'arccos': 'np.arccos',
            'arctan': 'np.arctan',
            'arcsinh': 'np.arcsinh',
            'arccosh': 'np.arccosh',
            'arctanh': 'np.arctanh',
            'π': 'np.pi',
            'e': 'np.e'
        }

        self.frame_entrada_funciones = tk.Frame(self)
        self.frame_entrada_funciones.grid(row=0, column=0, sticky="nsew")
        self.frame_entrada_funciones.columnconfigure(0, weight = 1)
        self.frame_entrada_funciones.rowconfigure(1, weight=1)

        # Crear frame para entrada de usuario de las funciones ----------------------------------------------------------------------------
        self.frame_entrada = tk.Frame(self.frame_entrada_funciones, bg=frame_verde2)
        self.frame_entrada.grid(column = 0, row = 0, sticky="nsew")

        self.frame_entrada.rowconfigure(0, weight=1)
        self.frame_entrada.columnconfigure(0, weight=1)

        self.entry_function = ctk.CTkEntry(self.frame_entrada, placeholder_text="f(x) = ",height=35,width=400,font=("Helvetica", 18),corner_radius=50,text_color="black",placeholder_text_color="black", fg_color=("#A6F4F7", "#A6F4F7"), state="normal")
        self.entry_function.pack(padx=15, pady= 15)
        self.graficar_button = ctk.CTkButton(self.frame_entrada, text="Graficar",height=35, width=100, command=self.add_function, font=("Helvetica", 16), text_color="#fff", fg_color="#019557", hover_color= "#027E4A", border_width=0, border_color="#fff", corner_radius=10)
        self.graficar_button.pack(pady=15)

        #----Parte inferior a los entries

        #Frame de manipulacion de funciones debajo de la entrada de funciones------------------------------------------------------------ 1 fila dos columnas
        self.frame_manipulacion_funciones = tk.Frame(self.frame_entrada_funciones)
        self.frame_manipulacion_funciones.grid(column = 0, row = 1, sticky="nsew")

        self.frame_manipulacion_funciones.rowconfigure(0, weight = 1)
        self.frame_manipulacion_funciones.columnconfigure(0, weight = 5)
        self.frame_manipulacion_funciones.columnconfigure(1, weight = 1)
                                                          
        
        #Frame bar interna izquierda dentro de manipulacion de funciones--------------------------------------------------------------------------1 col 2 filas
        self.frame_barra_interna_izquierda = tk.Frame(self.frame_manipulacion_funciones, bg = gris_oscuro_barra_izquierda)
        self.frame_barra_interna_izquierda.grid(column = 0, row = 0, sticky="nsew")
        
        self.frame_barra_interna_izquierda.columnconfigure(0, weight = 1)
        self.frame_barra_interna_izquierda.rowconfigure(0, weight = 10)
        self.frame_barra_interna_izquierda.rowconfigure(1, weight = 1)

        #Frame para ajuste de limites------------------------------------------------------------------------------------------------------
        self.frame_ajuste_limites = tk.Frame(self.frame_barra_interna_izquierda, bg = "#736D68")
        self.frame_ajuste_limites.grid(column = 0, row = 1, sticky="nsew")

        self.frame_ajuste_limites.columnconfigure(0, weight = 1)
        self.frame_ajuste_limites.columnconfigure(1, weight = 1)
        

        self.frame_ajuste_limites.rowconfigure(0, weight = 1)
        self.frame_ajuste_limites.rowconfigure(1, weight = 1)
        self.frame_ajuste_limites.rowconfigure(2, weight = 1)

        #Entries for X-axis limits
        self.x_min_entry = ctk.CTkEntry(self.frame_ajuste_limites, placeholder_text="X min",font=("Helvetica", 15), width=120, corner_radius=10,text_color="black",placeholder_text_color="black", fg_color=("#A6F4F7", "#A6F4F7"), state="normal",)
        self.x_min_entry.grid(column = 0, row = 0, sticky = "ns", padx=5, pady=5)

        self.x_max_entry = ctk.CTkEntry(self.frame_ajuste_limites, placeholder_text="X max",font=("Helvetica", 15), width=120, corner_radius=10,text_color="black",placeholder_text_color="black", fg_color=("#A6F4F7", "#A6F4F7"), state="normal",)
        self.x_max_entry.grid(column = 0, row = 1, sticky = "ns", padx=5, pady=5)

        # Entries for Y-axis limits
        self.y_min_entry = ctk.CTkEntry(self.frame_ajuste_limites, placeholder_text="Y min",font=("Helvetica", 15), width=120, corner_radius=10,text_color="black",placeholder_text_color="black", fg_color=("#A6F4F7", "#A6F4F7"), state="normal",)
        self.y_min_entry.grid(column = 1, row = 0, sticky = "ns", padx=5, pady=5)

        self.y_max_entry = ctk.CTkEntry(self.frame_ajuste_limites, placeholder_text="Y max",font=("Helvetica", 15), width=120, corner_radius=10,text_color="black",placeholder_text_color="black", fg_color=("#A6F4F7", "#A6F4F7"), state="normal",)
        self.y_max_entry.grid(column = 1, row = 1, sticky = "ns", padx=5, pady=5)

        #Update axis button
        self.update_axis_button = tk.Button(self.frame_ajuste_limites, width=30, text="Actualizar Ejes", command=self.update_axis, bg=frame_verde2, borderwidth=0, foreground= "#fff", font=("Helvetica", 12), highlightbackground="#1f1f1f")
        self.update_axis_button = ctk.CTkButton(self.frame_ajuste_limites, text="Actualizar Ejes", command=self.update_axis, font=("Helvetica", 14), text_color="#fff", fg_color=frame_verde2, hover_color= frame_verde3, border_width=2, border_color= "#736D68", corner_radius=10)
        self.update_axis_button.grid(column = 0, row = 2, columnspan=2, sticky="nsew")

        #Frame calculadora------------------------------------------------------------------------------------------------------------------------------------------------
        self.frame_calculadora = tk.Frame(self.frame_barra_interna_izquierda, bg="#464648")
        self.frame_calculadora.rowconfigure(0, weight=1)
        self.frame_calculadora.rowconfigure(1, weight=8)
        self.frame_calculadora.columnconfigure(0, weight=1)
        self.frame_calculadora.grid(column = 0, row = 0, sticky="nsew")


        #Frame superior calculadora------------------------------------------------------------------------------------------------------------------------------------------------
        # Configuración del Frame Superior
        self.frame_superior_calculadora = tk.Frame(self.frame_calculadora, bg="#464648")
        self.frame_superior_calculadora.grid(column=0, row=0, sticky="nsew")
        self.frame_superior_calculadora.columnconfigure(0, weight=1)
        self.frame_superior_calculadora.columnconfigure(1, weight=6)  # 60% de peso
        self.frame_superior_calculadora.columnconfigure(2, weight=1)

        # Botón 1
        self.move_left = ctk.CTkButton(self.frame_superior_calculadora,width = 30,text="<", anchor="center", command=self.mover_izquierda, font=("Helvetica", 14), text_color="#fff", fg_color=frame_verde2, hover_color=frame_verde3, border_width=0, border_color="#736D68", corner_radius=3)
        self.move_left.grid(column=0, row=0, pady=2, sticky="nsew")

        # Entry
        self.entry_calculadora = ctk.CTkEntry(self.frame_superior_calculadora, width = 90,placeholder_text="Resultado: ", font=("Helvetica", 14), corner_radius=7, text_color="black", placeholder_text_color="black", fg_color=("#A6F4F7", "#A6F4F7"), state="normal")
        self.entry_calculadora.grid(column=1, row=0, padx=5, sticky="nsew")

        # Botón 2
        self.move_right = ctk.CTkButton(self.frame_superior_calculadora, width = 30, text=">", anchor="center", command=self.mover_derecha, font=("Helvetica", 14), text_color="#fff", fg_color=frame_verde2, hover_color=frame_verde3, border_width=0, border_color="#736D68", corner_radius=3)
        self.move_right.grid(column=2, row=0, pady=2, sticky="nsew")
        #Frame botones------------------------------------------------------------------------------------------------------------------------------------------------
        self.frame_botones_calculadora = tk.Frame(self.frame_calculadora, bg="#464648")
        self.frame_botones_calculadora.grid(column = 0, row = 1, sticky="nsew", padx=5, pady=2)


        self.calculator()

        #Barra interna derecha para la muestra de funciones------------------------------------------------------------------------------------
        self.frame_barra_interna_derecha = tk.Frame(self.frame_manipulacion_funciones)
        self.frame_barra_interna_derecha.grid(column=1, row=0, sticky="nsew")
        self.frame_barra_interna_derecha.rowconfigure(0, weight=1)
        self.frame_barra_interna_derecha.rowconfigure(1, weight=10)
        self.frame_barra_interna_derecha.columnconfigure(0, weight=1)

        self.label_funciones = tk.Label(self.frame_barra_interna_derecha, text="Tus funciones", bg="#019557", padx=0, pady=0, font=("Helvetica", 20), foreground="#fff")
        self.label_funciones.grid(column = 0, row = 0, sticky="nsew")

        self.frame_labels = tk.Frame(self.frame_barra_interna_derecha)
        self.frame_labels.grid(column = 0, row = 1, sticky="nsew")

        self.scrollBar = tk.Scrollbar(self.frame_labels)
        self.scrollBar.pack(fill="y", side="right")


        self.canvas2 = tk.Canvas(self.frame_labels, yscrollcommand=self.scrollBar.set)

        self.elframe = tk.Frame(self.canvas2)

        self.scrollBar.configure(command = self.canvas2.yview)

        self.window_id = self.canvas2.create_window(0,0, window=self.elframe, anchor='nw')
        self.canvas2.bind("<Configure>", self.on_canvas_configure)
        self.canvas2.pack(side = "left", fill="both", expand=True)

        #frame para la gráfica-----------------------------------------------------------------------------------------------------------------
        frame_grafica = tk.Frame(self)
        frame_grafica.grid(row=0, column=1, sticky="nsew")



        # Configuración de la gráfica de matplotlib
        self.fig, self.ax = plt.subplots()
        plt.grid(True)
        self.canvas = FigureCanvasTkAgg(self.fig, master=frame_grafica)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(expand=True, fill="both")


        #_________________________________________________________________________________________________________________________________________________________________________________________

        self.functions_list = []
        self.active_functions_list = []
        self.lines_functions_list = []
        self.all_frames = []
        self.count_func = 0   
        
    def add_function(self):
        raw_func_input = self.entry_function.get()
        func_input = self.preprocess_input(raw_func_input)
        self.entry_function.delete(0, tk.END)
        if func_input and func_input not in self.functions_list:
            # Try to create a function from the input string
            self.plot_function(func_input, raw_func_input)
            messagebox.showerror("Atencion", "Introduce una funcion valida!.")    
        else:
            messagebox.showerror("Atencion", "ya has introducido esta funcion.")

    def plot_function(self, func_input, raw_func_input ):
            if self.x_max_entry.get() == "" or self.x_min_entry.get() == "":
                x_min, x_max = self.determine_x_limits(func_input)
            else:
                x_min = float(self.x_min_entry.get())
                x_max = float(self.x_max_entry.get())
            x = np.linspace(x_min, x_max, 400)
            y = eval(f"np.vectorize(lambda x: {func_input})(x)")
            self.functions_list.append(func_input)
            self.active_functions_list.append(func_input)
            line, = self.ax.plot(x, y, label=func_input)
            self.lines_functions_list.append(line)
            self.update_plot()
            self.add_label(raw_func_input)

    def determine_x_limits(self, func_input):
        # Analizar el tipo de función y determinar los límites adecuados para el eje x.
        if 'sin' in func_input or 'cos' in func_input:
            return -2 * np.pi, 2 * np.pi
        elif 'tan' in func_input:
            return -np.pi / 2, np.pi / 2
        elif 'log' in func_input:
            return 0.1, 10  # Evitar el log(0) que es indefinido.
        else:
            return -10, 10  # Límites predeterminados.

    def add_label(self, raw_func_input):
        label_frame = tk.Frame(self.elframe, bg=gris_barra_izquierda)
        label_frame.pack(fill="both", side="top")
        self.all_frames.append(label_frame)

        label_entry = ctk.CTkEntry(label_frame, placeholder_text="Ingrese función", font=("Helvetica", 16),corner_radius=5,text_color="black",placeholder_text_color="black", fg_color=("#A6F4F7", "#A6F4F7"), state="normal",)
        label_entry.pack(padx=5, pady= 10)
        label_entry.insert(0, str(raw_func_input))

        toggle_button = ttk.Checkbutton(label_frame, style="CustomCheckbutton.TCheckbutton" , text="Show", command=lambda: self.toggle_function(self.functions_list[self.all_frames.index(label_frame)], label_entry.get()))
        toggle_button.pack(side="left")

        actualizar_button = ctk.CTkButton(label_frame, text="", fg_color=gris_barra_izquierda, width=100, hover_color=gris_oscuro_barra_izquierda, command=lambda: self.modify_function(self.preprocess_input(label_entry.get()), self.functions_list[self.all_frames.index(label_frame)]), image=self.photo_refresh)
        actualizar_button.image = self.photo_refresh
        actualizar_button.pack(side="right")

        borrar_button = ctk.CTkButton(label_frame, text="", fg_color=gris_barra_izquierda, width=100, hover_color=gris_oscuro_barra_izquierda, command=lambda frame = label_frame: self.delete_function(frame), image=self.photo_bin)
        borrar_button.image = self.photo_bin
        borrar_button.pack(side="right")

        toggle_button.state(['selected'])  # Initially show the function

        self.frame_barra_interna_derecha.update()
        self.canvas2.config(scrollregion=self.canvas2.bbox("all"))
        
    def toggle_function(self, func_input, label_input):
        processed_label = self.preprocess_input(label_input)
        if func_input == processed_label:
            if func_input in self.active_functions_list:
                self.lines_functions_list[self.functions_list.index(func_input)].set_visible(False)
                self.active_functions_list[self.functions_list.index(func_input)] = False
            else:
                self.lines_functions_list[self.functions_list.index(func_input)].set_visible(True)
                self.active_functions_list[self.functions_list.index(func_input)] = func_input
        else:
            if processed_label in self.active_functions_list:
                self.lines_functions_list[self.functions_list.index(processed_label)].set_visible(False)
                self.active_functions_list[self.functions_list.index(processed_label)] = False
            else:
                self.lines_functions_list[self.functions_list.index(processed_label)].set_visible(True)
                self.active_functions_list[self.functions_list.index(processed_label)] = processed_label        
        self.update_plot()

    def update_plot(self):
        self.canvas.draw()

    def update_axis(self):
        if not (self.x_max_entry.get() == "" or self.x_min_entry.get() == "" or self.y_max_entry.get() == "" or self.y_min_entry.get() == ""): 
            try:
                x_min = float(self.x_min_entry.get())
                x_max = float(self.x_max_entry.get())
                y_min = float(self.y_min_entry.get())
                y_max = float(self.y_max_entry.get())
                if x_min < x_max and y_min < y_max:
                    self.ax.set_xlim([x_min, x_max])
                    self.ax.set_ylim([y_min, y_max])
                    self.update_plot()
                else:
                        messagebox.showerror("Error", "Los limites inferiores deben ser menores que los máximos.")
            except ValueError:
                messagebox.showerror("Error", "Los limites deben ser datos numericos.")
        else:
            messagebox.showerror("Error", "Rellena los campos de los limites!")

    def preprocess_input(self, raw_function):
        for key in sorted(self.function_dict, key=len, reverse=True):
            pattern = r'\b' + re.escape(key) + r'\b'  # \b indica un límite de palabra
            raw_function = re.sub(pattern, self.function_dict[key], raw_function)
        return raw_function
    
    def modify_function(self, label_entry, old_processed_function):
        if label_entry and (label_entry not in self.functions_list) and (label_entry != old_processed_function): #si la funcion actual no se encuentra en la lista de funciones:
            try:
                self.update_old_function(label_entry, old_processed_function)
            except Exception as e:
                messagebox.showerror("Atencion", "Introduce una funcion valida!.")   
        else:
            messagebox.showerror("Atencion", "Ya has introducido esa funcion")

    def update_old_function(self, new_processed_function, old_processed_function):
        try:
            # Establecemos el índice anterior, comprobando si realmente existe
            old_index = self.functions_list.index(old_processed_function)
        except ValueError:
            messagebox.showerror("Error", "La función original ya no existe en la lista.")
            return
        # Ocultamos la línea de la función antigua y actualizamos las listas
        self.lines_functions_list[old_index].set_visible(False)
        self.active_functions_list[old_index] = new_processed_function
        self.functions_list[old_index] = new_processed_function
        if self.x_max_entry.get() == "" or self.x_min_entry.get() == "":
            x_min, x_max = self.determine_x_limits(new_processed_function)
        else:
            x_min = float(self.x_min_entry.get())
            x_max = float(self.x_max_entry.get())
        x = np.linspace(x_min, x_max, 400)
        y = eval(f"np.vectorize(lambda x: {new_processed_function})")(x)
        new_line, = self.ax.plot(x, y, label=new_processed_function)
        self.lines_functions_list[old_index] = new_line
        self.update_plot()

    def on_canvas_configure(self, event):
        self.canvas_width = event.width 
        self.canvas2.itemconfig(self.window_id, width=self.canvas_width)

    def delete_function(self, actual_frame):
        try:
            index = self.all_frames.index(actual_frame)
        except ValueError:
            messagebox.showerror("Error", "La función original ya no existe en la lista.")
            return

        self.lines_functions_list[index].set_visible(False)
        self.lines_functions_list.pop(index)
        self.active_functions_list.pop(index)
        self.functions_list.pop(index)

        self.all_frames.remove(actual_frame)
        actual_frame.pack_forget()
        self.update_plot()

    def mover_derecha(self):
        index = self.entry_calculadora.index(tk.INSERT)
        index +=1
        self.entry_calculadora.icursor(index)

    def mover_izquierda(self):
        index = self.entry_calculadora.index(tk.INSERT)
        index -=1
        self.entry_calculadora.icursor(index)

    def calculator(self):
        self.gris = "#BCC2CD"
        self.gris_hover = "#99A0AE"
        self.amarillo = "#EBA447"
        self.amarillo_hover = "#D0913E"
        self.verde = "#53C396"
        self.verde_hover = "#47A780"
        self.color_texto = "#464648"
        self.color_botones = "#2E2A2A"
        self.color_botones_hover = "#1C1C1C"
        self.color_operaciones = "#6F6F71"
        self.color_operaciones_hover = "#4D4D4D"
        self.color_numeros = "#C1C2C4"

        delete = Image.open(delete_calculator_address)
        graph = Image.open(graph_address)
        gamma = Image.open(gamma_address)
        sqrt = Image.open(sqrt_address)
        tick = Image.open(tick_address)
        summation = Image.open(summation_address)

        delete = delete.resize((20,  int((float(delete.size[1]) * float((20 / float(delete.size[0])))))))
        self.photo_delete = ctk.CTkImage(delete)

        graph = graph.resize((20,  int((float(graph.size[1]) * float((20 / float(graph.size[0])))))))
        self.photo_graph = ctk.CTkImage(graph)
        
        gamma = gamma.resize((20,  int((float(gamma.size[1]) * float((20 / float(gamma.size[0])))))))
        self.photo_gamma = ctk.CTkImage(gamma)

        sqrt = sqrt.resize((30,  int((float(sqrt.size[1]) * float((30 / float(sqrt.size[0])))))))
        self.photo_sqrt = ctk.CTkImage(sqrt)

        tick = tick.resize((100,  int((float(tick.size[1]) * float((100 / float(tick.size[0])))))))
        self.photo_tick = ctk.CTkImage(tick)
        
        summation = summation.resize((20,  int((float(summation.size[1]) * float((20 / float(summation.size[0])))))))
        self.photo_summation = ctk.CTkImage(summation)

        self.images = {
            "delete": self.photo_delete,
            "graph": self.photo_graph,
            "gamma": self.photo_gamma,
            "sqrt": self.photo_sqrt,
            "tick": self.photo_tick,
            "summation": self.photo_summation
        }
        for col in range(5):
            self.frame_botones_calculadora.columnconfigure(col, weight=1, minsize=52, uniform="button_col")
        
        self.button_configs = []  # Almacenar configuración de cada botón
        for i in range(45):  # Total de 45 botones
            if i == 0:
                config = {"text": "", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 14, "bold"), "text_color":"#000", "command": lambda: self.on_button_click("gamma"), "image": self.images["gamma"]}
            elif i == 1:
                config = {"text": "SHIFT", "fg_color": self.verde, "hover_color": self.verde_hover,"text_color": self.color_texto, "font": ("Helvetica", 12, "bold"), "command": lambda: self.on_button_click("shift")}
            elif i == 2:
                config = {"text": "ʃdx", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 18, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("integral")}
            elif i == 3:
                config = {"text": "", "fg_color": self.amarillo, "hover_color": self.amarillo_hover, "font": ("Helvetica", 14, "bold"), "text_color":"#000","command": lambda: self.on_button_click("delete"), "image":self.images["delete"] }
            elif i == 4:
                config = {"text": "AC", "fg_color": self.amarillo, "hover_color": self.amarillo_hover, "font": ("Helvetica", 16, "bold"), "text_color": self.color_texto, "command": lambda: self.on_button_click("ac")}
            elif i == 5:
                config = {"text": "DRG", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 14, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("drg")}
            elif i == 6:
                config = {"text": "RAD", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 14, "bold"), "text_color":self.color_texto,"command": lambda: self.on_button_click("rad")}
            elif i == 7:
                config = {"text": "d/dx", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_texto,"command": lambda: self.on_button_click("derivative")}
            elif i == 8:
                config = {"text": "", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 14, "bold"), "text_color":"#000", "command": lambda: self.on_button_click("summation"), "image": self.images["summation"]}
            elif i == 9:
                config = {"text": "Logₐ(x)", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Arial Narrow", 12.5, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("loga(x)")}            
            elif i == 10:
                config = {"text": "π", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("pi")}
            elif i == 11:
                config = {"text": "sin(x)", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Arial Narrow", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("sin(x)")}
            elif i == 12:
                config = {"text": "cos(x)", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Arial Narrow", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("cos(x)")}            
            elif i == 13:
                config = {"text": "tan(x)", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Arial Narrow", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("tan(x)")}            
            elif i == 14:
                config = {"text": "x!", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("x!")}            
            elif i == 15:
                config = {"text": "e", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("e")}            
            elif i == 16:
                config = {"text": "sin⁻¹(x)", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Arial Narrow", 12.5, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("arcsin(x)")}            
            elif i == 17:
                config = {"text": "cos⁻¹(x)", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Arial Narrow", 12.5, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("arccos(x)")}            
            elif i == 18:
                config = {"text": "tan⁻¹(x)", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Arial Narrow", 12.5, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("arctan(x)")}                        
            elif i == 19:
                config = {"text": "xⁿ", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("x**n")}                        
            
            elif i == 20:
                config = {"text": "7", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("7")}                        
            elif i == 21:
                config = {"text": "8", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("8")}                        
            elif i == 22:
                config = {"text": "9", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("9")}                        
            elif i == 25:
                config = {"text": "4", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("4")}                        
            elif i == 26:
                config = {"text": "5", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("5")}                        
            elif i == 27:
                config = {"text": "6", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("6")}                        
            elif i == 30:
                config = {"text": "1", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("1")}                        
            elif i == 31:
                config = {"text": "2", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("2")}                        
            elif i == 32:
                config = {"text": "3", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("3")}                        
            elif i == 35:
                config = {"text": "0", "fg_color": self.color_botones, "hover_color": self.color_botones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("0")}       
                                 
            elif i == 23:
                config = {"text": "X", "fg_color": self.verde, "hover_color": self.verde_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("x")}                        
            elif i == 24:
                config = {"text": "", "fg_color": self.gris, "hover_color": self.gris_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("sqrt(x)"), "image": self.images["sqrt"]}            
            elif i == 28:
                config = {"text": "(", "fg_color": self.color_operaciones, "hover_color": self.color_operaciones_hover, "font": ("Helvetica", 25, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("(")}                        
            elif i == 29:
                config = {"text": ")", "fg_color": self.color_operaciones, "hover_color": self.color_operaciones_hover, "font": ("Helvetica", 25, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click(")")}                        
            elif i == 33:
                config = {"text": "X", "fg_color": self.color_operaciones, "hover_color": self.color_operaciones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("mul")}                        
            elif i == 34:
                config = {"text": "÷", "fg_color": self.color_operaciones, "hover_color": self.color_operaciones_hover, "font": ("Helvetica", 25, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("div")}                        
            elif i == 36:
                config = {"text": "Ans", "fg_color": self.color_operaciones, "hover_color": self.color_operaciones_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("ans")}                        
            elif i == 37:
                config = {"text": "", "fg_color": self.amarillo, "hover_color": self.amarillo_hover, "font": ("Helvetica", 16, "bold"), "text_color":self.color_texto, "command": lambda: self.on_button_click("tick"), "image": self.images["tick"]}                        
            
            elif i == 38:
                config = {"text": "+", "fg_color": self.color_operaciones, "hover_color": self.color_operaciones_hover, "font": ("Helvetica", 25, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("sum")}                        
            elif i == 39:
                config = {"text": "-", "fg_color": self.color_operaciones, "hover_color": self.color_operaciones_hover, "font": ("Helvetica", 25, "bold"), "text_color":self.color_numeros, "command": lambda: self.on_button_click("res")}                        

            self.button_configs.append(config)

        count = 0
        for row in range(8):  # 8 filas
            self.frame_botones_calculadora.rowconfigure(row, weight=1, minsize=50)
            for col in range(5):  # 5 columnas
                if count >= len(self.button_configs):
                    break  # Asegura que no intentamos configurar un botón que no existe
                config = self.button_configs[count]
                if "image" in config:
                    button = ctk.CTkButton(
                        self.frame_botones_calculadora,
                        width=1,
                        text=config["text"],
                        fg_color=config["fg_color"],
                        command=config["command"],
                        image=config["image"],
                        compound="left",
                        hover_color=config["hover_color"],
                        text_color=config["text_color"],
                        font=config["font"]
                    )
                else:
                    button = ctk.CTkButton(
                        self.frame_botones_calculadora,
                        width=5,
                        text=config["text"],
                        fg_color=config["fg_color"],
                        command=config["command"],
                        hover_color=config["hover_color"],
                        text_color=config["text_color"],
                        font=config["font"]
                    )
                button.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
                count += 1

    def on_button_click(self, button_value):                   
        if button_value == "delete":
            self.borrar_caracter()
        elif button_value == "ac":
            self.entry_calculadora.delete(0, tk.END)
        elif button_value == "shift":
            self.shift()
            self.change_widgets()
        elif button_value == "gamma":
            self.apply_func("Γ")
        elif button_value == "integral":
            self.apply_func("ʃ")           
        elif button_value == "drg":
            self.change_to_drg()            
        elif button_value == "rad":
            self.change_to_rad()            
        elif button_value == "derivative":
            self.apply_func("d/dx")            
        elif button_value == "summation":
            self.apply_func("Σ")          
        elif button_value == "loga(x)":
            self.apply_func("log")       
        elif button_value == "ln(x)":
            self.apply_func("ln")           
        elif button_value == "pi":
            self.insert_character("π")

        elif button_value == "sin(x)":
            self.apply_func("sin")           
        elif button_value == "cos(x)":
            self.apply_func("cos")
        elif button_value == "tan(x)":
            self.apply_func("tan")     

        elif button_value == "x!":
            self.apply_factorial()          
        elif button_value == "e":
            self.insert_character("e")                        
        elif button_value == "arcsin(x)":
            self.apply_func("arcsin")     
        elif button_value == "arccos(x)":
            self.apply_func("arcscos")
        elif button_value == "arctan(x)":
            self.apply_func("arctan")

        elif button_value == "x**n":
            self.apply_power("N")

        elif button_value == "7":
            self.insert_character("7")
        elif button_value == "8":
            self.insert_character("8")
        elif button_value == "9":
            self.insert_character("9")
        elif button_value == "4":
            self.insert_character("4")            
        elif button_value == "5":
            self.insert_character("5")            
        elif button_value == "6":
            self.insert_character("6")            
        elif button_value == "1":
            self.insert_character("1")            
        elif button_value == "2":
            self.insert_character("2")            
        elif button_value == "3":
            self.insert_character("3")            
        elif button_value == "0":
            self.insert_character("0")
        elif button_value == "x":
            self.insert_character("x")


        elif button_value == "ans":
            self.print_previous_value()            
        elif button_value == "tick":
            self.send_value()            
        elif button_value == "x**2":
            self.apply_power("2")        
        elif button_value == "sqrt(x)":
            self.apply_func("sqrt")
        elif button_value == "(":
            self.insert_character("(")         
        elif button_value == ")":
            self.insert_character(")")         
        elif button_value == "mul":
            self.insert_character("*")            
        elif button_value == "div":
            self.insert_character("/")            
        elif button_value == "sum":
            self.insert_character("+")            
        elif button_value == "res":
            self.insert_character("-")     

        elif button_value == "integral_definida":
            self.apply_func("ʃ_")

        elif button_value == "sinh(x)":
            self.apply_func("sinh")   
        elif button_value == "cosh(x)":
            self.apply_func("cosh")   
        elif button_value == "tanh(x)":
            self.apply_func("tanh")   
        elif button_value == "arcsinh(x)":
            self.apply_func("arcsinh")   
        elif button_value == "arccosh(x)":
            self.apply_func("arccosh")   
        elif button_value == "arctanh(x)":
            self.apply_func("arctanh")   
        else:
            print("Operación no reconocida")

    def send_value(self):
        str_func = self.entry_calculadora.get()
        self.normalize_function(str_func)
        
    def normalize_function(self, raw_func):
        
        self.entry_function.delete(0, tk.END)
        modified_func = self.replace_expressions(raw_func)
        self.ans.append(modified_func)
        self.entry_function.insert(0, modified_func)

    def eval_function2(self, func_str, x_val):
        # Evaluar una función en un punto específico
        # x = np.array([x_val], dtype=float)
        return eval(func_str)

    def replace_expressions(self, str_func):
        while 'd/dx(' in str_func:
            str_func = re.sub(r'd/dx\(([^()]+?)\)', lambda match: self.process_derivative(match.group(1)),str_func)
            
        # Expresión regular para capturar integrales indefinidas
        str_func = re.sub(r'ʃ\(([^,]+),\s*([^,]+)\)', lambda match: self.process_integral(match.group(1).strip(), match.group(2).strip()), str_func)
        
        str_func = re.sub(r'ʃ_\(([^,]+),\s*([^,]*),?\s*([^,]*),?\s*([^,]*)\)', lambda match: self.process_integral_definida(match.group(1).strip(), match.group(2).strip(), match.group(3).strip(), match.group(4).strip()), str_func)

        str_func = re.sub(r'Σ\((.*?),(.*?),(.*?),(.*?)\)', lambda match: self.process_sum(match.group(1), match.group(2), match.group(3), match.group(4)),str_func)
        str_func = re.sub(r'log\((.*?),(.*?)\)', lambda match: f"log({match.group(2)}) / log({match.group(1)})",str_func)
        str_func = re.sub(r'ln\((.*?)\)', lambda match: f"log({match.group(1)}) / log(e)", str_func)

        str_func = self.replace_factorial_with_gamma(str_func)

        if self.deg_mode:
            str_func = self.convert_radians_to_degrees(str_func)
        return str_func

    def replace_factorial_with_gamma(self, expression):
        # Expresión regular para encontrar (algo)!
        pattern = r'\(([^()]*(?:\([^()]*\)[^()]*)*)\)!'

        # Función de reemplazo
        def replacer(match):
            # Extraer el contenido del paréntesis
            content = match.group(1)
            # Crear la expresión con la función gamma
            return f'Γ({content} + 1)'

        # Usar re.sub para reemplazar según el patrón
        result = re.sub(pattern, replacer, expression)

        return result

    def print_previous_value(self):
        index = self.entry_calculadora.index(tk.INSERT)
        last_value = self.ans[-1]
        if  last_value == "0":
            pass
        else:
            self.entry_calculadora.insert(index, last_value)

    def process_integral(self, expression, variable):
        var_symbol = symbols(variable.strip())
        expr = sympify(expression)
        integral_result = integrate(expr, var_symbol)
        return str(integral_result)

    def process_integral_definida(self, expression, lim_inf, lim_sup, var):
        var_symbol = symbols(var.strip())
        expr = sympify(expression)
        lim_inf = sympify(lim_inf.strip())
        lim_sup = sympify(lim_sup.strip())
        integral_result = integrate(expr, (var_symbol, lim_inf, lim_sup))
        return str(integral_result)

    def process_derivative(self, expression):
        # Evaluar la expresión usando sympify para convertirla en una expresión de SymPy
        expr = sympify(expression)
        # Calcular la derivada de la expresión
        derivative = diff(expr, self.x)
        return str(derivative)

    def process_sum(self, expression, lim_inf, lim_sup, var):
        # Crear la variable simbólica a partir de la cadena
        var_symbol = symbols(str(var))

        # Evaluar la expresión usando eval para que incluya la variable correcta
        expr = sympify(expression, {"x": self.x, var: var_symbol})
        # Evaluar los límites de la sumatoria
        lim_inf = int(lim_inf)
        lim_sup = int(lim_sup)
            
        # Usar sympy summation para evaluar la sumatoria simbólicamente
        sum_result = summation(expr, (var_symbol, lim_inf, lim_sup))
        return str(sum_result)
    
    def apply_func(self, func_str):
        if func_str == "Σ":
            func_parentesis = func_str + "(f, inf, sup, var)"
        elif func_str == "log":
            func_parentesis = func_str + "(b, f)"
        elif func_str == "ʃ": 
            func_parentesis = func_str + "(f, var)"
        elif func_str == "ʃ_": 
            func_parentesis = func_str + "(f, lim_inf, lim_sup, var)"
        else:
            func_parentesis = func_str + "()"
        
        func_parentesis1 = func_str + "("
        content = self.entry_calculadora.get()
        self.entry_calculadora.focus_set()
        cursor_pos = self.entry_calculadora.index(tk.INSERT)
        
        if len(content) == 0:
            self.entry_calculadora.insert(0, func_parentesis)
            self.entry_calculadora.icursor(self.find_opening_parenthesis(self.entry_calculadora.get(), 0))
            return
        
        # Revisa si el cursor está al lado de un paréntesis que abre
        if cursor_pos < len(content) and content[cursor_pos] == '(':
            close_pos = self.find_closing_parenthesis(content, cursor_pos)
            if close_pos != -1:
                new_content = content[:cursor_pos] + func_str + content[cursor_pos:close_pos+1] + content[close_pos+1:]
                self.entry_calculadora.delete(0, "end")
                self.entry_calculadora.insert(0, new_content)
                self.entry_calculadora.icursor(self.find_opening_parenthesis(self.entry_calculadora.get(), cursor_pos))
                return
        
        # Buscar el primer elemento a la derecha del cursor
        right_part = content[cursor_pos:]
        # Actualización de la regex para manejar correctamente las funciones
        match = re.search(r"(sin|cos|tan|d/dx|Γ|sqrt|Σ|ʃ|ʃ_|log|arcsin|arccos|arctan|sinh|cosh|tanh|arcsinh|arccosh|arctanh)\(.*?\)|[\d\w\.]+", right_part, re.DOTALL)
        if match:
            start = match.start()
            end = match.end()
            new_content = content[:cursor_pos] + func_parentesis1 + content[cursor_pos + start:cursor_pos + end] + ")" + content[cursor_pos + end:]
            self.entry_calculadora.delete(0, "end")
            self.entry_calculadora.insert(0, new_content)
            self.entry_calculadora.icursor(self.find_opening_parenthesis(self.entry_calculadora.get(), cursor_pos + start))
        else:
            self.entry_calculadora.insert(cursor_pos, func_parentesis)
            self.entry_calculadora.icursor(self.find_opening_parenthesis(self.entry_calculadora.get(), cursor_pos))

    def convert_radians_to_degrees(self, expression):
        conversion_factor = "*(π/180)" 
        trig_pattern = re.compile(r'\b(sin|cos|tan|arcsin|arccos|arctan)\(([^()]+)\)')
        def replace_trig(match):
            func_name = match.group(1)
            argument = match.group(2)
            return f"{func_name}({argument}{conversion_factor})"
        expression = re.sub(trig_pattern, replace_trig, expression)
        return expression

    def change_to_drg(self):
        self.rad_mode = False
        self.deg_mode = True
        if self.deg_mode:
            self.button_configs[6]["fg_color"] = self.gris
            self.button_configs[6]["hover_color"] = self.gris_hover
            self.button_configs[5]["fg_color"] = self.verde
            self.button_configs[5]["hover_color"] = self.verde_hover
        else:
            self.button_configs[6]["fg_color"] = self.verde
            self.button_configs[6]["hover_color"] = self.verde_hover
            self.button_configs[5]["fg_color"] = "#337C5F"
            self.button_configs[5]["hover_color"] = "#265C46"
        button = ctk.CTkButton(
            self.frame_botones_calculadora,
            width=5,
            text=self.button_configs[5]["text"],
            fg_color=self.button_configs[5]["fg_color"],
            command=self.button_configs[5]["command"],
            hover_color=self.button_configs[5]["hover_color"],
            text_color=self.button_configs[5]["text_color"],
            font=self.button_configs[5]["font"])
        button.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        
        button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[6]["text"],
                fg_color=self.button_configs[6]["fg_color"],
                command=self.button_configs[6]["command"],
                hover_color=self.button_configs[6]["hover_color"],
                text_color=self.button_configs[6]["text_color"],
                font=self.button_configs[6]["font"])
        button.grid(row=1, column=1, sticky="nsew", padx=4, pady=4)
    
    def change_to_rad(self):
        self.rad_mode = True
        self.deg_mode = False
        if self.rad_mode:
            self.button_configs[5]["fg_color"] = self.gris
            self.button_configs[5]["hover_color"] = self.gris_hover
            self.button_configs[6]["fg_color"] = self.verde
            self.button_configs[6]["hover_color"] = self.verde_hover
        else:
            self.button_configs[5]["fg_color"] = self.verde
            self.button_configs[5]["hover_color"] = self.verde_hover
            self.button_configs[6]["fg_color"] = self.gris
            self.button_configs[6]["hover_color"] = self.gris_hover
        button = ctk.CTkButton(
            self.frame_botones_calculadora,
            width=5,
            text=self.button_configs[5]["text"],
            fg_color=self.button_configs[5]["fg_color"],
            command=self.button_configs[5]["command"],
            hover_color=self.button_configs[5]["hover_color"],
            text_color=self.button_configs[5]["text_color"],
            font=self.button_configs[5]["font"])
        
        button.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)

        button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[6]["text"],
                fg_color=self.button_configs[6]["fg_color"],
                command=self.button_configs[6]["command"],
                hover_color=self.button_configs[6]["hover_color"],
                text_color=self.button_configs[6]["text_color"],
                font=self.button_configs[6]["font"])
        button.grid(row=1, column=1, sticky="nsew", padx=4, pady=4)

    def shift(self):
        if self.shift_active:
            self.shift_active = False
            self.button_configs[1]["fg_color"] = self.verde
            self.button_configs[1]["hover_color"] = self.verde_hover
        else:
            self.shift_active = True
            self.button_configs[1]["fg_color"] = "#337C5F"
            self.button_configs[1]["hover_color"] = "#265C46"

        button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[1]["text"],
                fg_color=self.button_configs[1]["fg_color"],
                command=self.button_configs[1]["command"],
                hover_color=self.button_configs[1]["hover_color"],
                text_color=self.button_configs[1]["text_color"],
                font=self.button_configs[1]["font"])
        button.grid(row=0, column=1, sticky="nsew", padx=4, pady=4)

    def change_widgets(self):
        if self.shift_active:
            self.button_configs[11]["text"] = "sinh(x)"
            self.button_configs[11]["command"] = lambda: self.on_button_click("sinh(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[11]["text"],
                fg_color=self.button_configs[11]["fg_color"],
                command=self.button_configs[11]["command"],
                hover_color=self.button_configs[11]["hover_color"],
                text_color=self.button_configs[11]["text_color"],
                font=self.button_configs[11]["font"])
            button.grid(row=2, column=1, sticky="nsew", padx=4, pady=4)


            self.button_configs[12]["text"] = "cosh(x)"
            self.button_configs[12]["command"] = lambda: self.on_button_click("cosh(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[12]["text"],
                fg_color=self.button_configs[12]["fg_color"],
                command=self.button_configs[12]["command"],
                hover_color=self.button_configs[12]["hover_color"],
                text_color=self.button_configs[12]["text_color"],
                font=self.button_configs[12]["font"])
            button.grid(row=2, column=2, sticky="nsew", padx=4, pady=4)


            self.button_configs[13]["text"] = "tanh(x)"
            self.button_configs[13]["command"] = lambda: self.on_button_click("tanh(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[13]["text"],
                fg_color=self.button_configs[13]["fg_color"],
                command=self.button_configs[13]["command"],
                hover_color=self.button_configs[13]["hover_color"],
                text_color=self.button_configs[13]["text_color"],
                font=self.button_configs[13]["font"])
            button.grid(row=2, column=3, sticky="nsew", padx=4, pady=4)


            self.button_configs[16]["text"] = "sinh⁻¹(x)"
            self.button_configs[16]["command"] = lambda: self.on_button_click("arcsinh(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[16]["text"],
                fg_color=self.button_configs[16]["fg_color"],
                command=self.button_configs[16]["command"],
                hover_color=self.button_configs[16]["hover_color"],
                text_color=self.button_configs[16]["text_color"],
                font=self.button_configs[16]["font"])
            button.grid(row=3, column=1, sticky="nsew", padx=4, pady=4)


            self.button_configs[17]["text"] = "cosh⁻¹(x)"
            self.button_configs[17]["command"] = lambda: self.on_button_click("arccosh(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[17]["text"],
                fg_color=self.button_configs[17]["fg_color"],
                command=self.button_configs[17]["command"],
                hover_color=self.button_configs[17]["hover_color"],
                text_color=self.button_configs[17]["text_color"],
                font=self.button_configs[17]["font"])
            button.grid(row=3, column=2, sticky="nsew", padx=4, pady=4)

            self.button_configs[18]["text"] = "tanh⁻¹(x)"
            self.button_configs[18]["command"] = lambda: self.on_button_click("arctanh(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[18]["text"],
                fg_color=self.button_configs[18]["fg_color"],
                command=self.button_configs[18]["command"],
                hover_color=self.button_configs[18]["hover_color"],
                text_color=self.button_configs[18]["text_color"],
                font=self.button_configs[18]["font"])
            button.grid(row=3, column=3, sticky="nsew", padx=4, pady=4)

            self.button_configs[2]["command"] = lambda: self.on_button_click("integral_definida")
            self.button_configs[2]["text"] = "ʃₐᵇdx"
            self.button_configs[2]["font"] = ("Helvetica", 15, "bold")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[2]["text"],
                fg_color=self.button_configs[2]["fg_color"],
                command=self.button_configs[2]["command"],
                hover_color=self.button_configs[2]["hover_color"],
                text_color=self.button_configs[2]["text_color"],
                font=self.button_configs[2]["font"])
            button.grid(row=0, column=2, sticky="nsew", padx=4, pady=4)

            self.button_configs[18]["text"] = "tanh⁻¹(x)"
            self.button_configs[18]["command"] = lambda: self.on_button_click("arctanh(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[18]["text"],
                fg_color=self.button_configs[18]["fg_color"],
                command=self.button_configs[18]["command"],
                hover_color=self.button_configs[18]["hover_color"],
                text_color=self.button_configs[18]["text_color"],
                font=self.button_configs[18]["font"])
            button.grid(row=3, column=3, sticky="nsew", padx=4, pady=4)

            self.button_configs[23]["text"] = "X²"
            self.button_configs[23]["command"] = lambda: self.on_button_click("x**2")
            self.button_configs[23]["fg_color"] = self.gris
            self.button_configs[23]["hover_color"] = self.gris_hover
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[23]["text"],
                fg_color=self.button_configs[23]["fg_color"],
                command=self.button_configs[23]["command"],
                hover_color=self.button_configs[23]["hover_color"],
                text_color=self.button_configs[23]["text_color"],
                font=self.button_configs[23]["font"])
            button.grid(row=4, column=3, sticky="nsew", padx=4, pady=4)
        

            self.button_configs[9]["text"] = "Ln(x)"
            self.button_configs[9]["command"] = lambda: self.on_button_click("ln(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[9]["text"],
                fg_color=self.button_configs[9]["fg_color"],
                command=self.button_configs[9]["command"],
                hover_color=self.button_configs[9]["hover_color"],
                text_color=self.button_configs[9]["text_color"],
                font=self.button_configs[9]["font"])
            button.grid(row=1, column=4, sticky="nsew", padx=4, pady=4)

        else:
            self.button_configs[11]["text"] = "sin(x)"
            self.button_configs[11]["command"] = lambda: self.on_button_click("sin(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[11]["text"],
                fg_color=self.button_configs[11]["fg_color"],
                command=self.button_configs[11]["command"],
                hover_color=self.button_configs[11]["hover_color"],
                text_color=self.button_configs[11]["text_color"],
                font=self.button_configs[11]["font"])
            button.grid(row=2, column=1, sticky="nsew", padx=4, pady=4)


            self.button_configs[12]["text"] = "cos(x)"
            self.button_configs[12]["command"] = lambda: self.on_button_click("cos(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[12]["text"],
                fg_color=self.button_configs[12]["fg_color"],
                command=self.button_configs[12]["command"],
                hover_color=self.button_configs[12]["hover_color"],
                text_color=self.button_configs[12]["text_color"],
                font=self.button_configs[12]["font"])
            button.grid(row=2, column=2, sticky="nsew", padx=4, pady=4)


            self.button_configs[13]["text"] = "tan(x)"
            self.button_configs[13]["command"] = lambda: self.on_button_click("tan(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[13]["text"],
                fg_color=self.button_configs[13]["fg_color"],
                command=self.button_configs[13]["command"],
                hover_color=self.button_configs[13]["hover_color"],
                text_color=self.button_configs[13]["text_color"],
                font=self.button_configs[13]["font"])
            button.grid(row=2, column=3, sticky="nsew", padx=4, pady=4)


            self.button_configs[16]["text"] = "sin⁻¹(x)"
            self.button_configs[16]["command"] = lambda: self.on_button_click("arcsin(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[16]["text"],
                fg_color=self.button_configs[16]["fg_color"],
                command=self.button_configs[16]["command"],
                hover_color=self.button_configs[16]["hover_color"],
                text_color=self.button_configs[16]["text_color"],
                font=self.button_configs[16]["font"])
            button.grid(row=3, column=1, sticky="nsew", padx=4, pady=4)


            self.button_configs[17]["text"] = "cos⁻¹(x)"
            self.button_configs[17]["command"] = lambda: self.on_button_click("arccos(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[17]["text"],
                fg_color=self.button_configs[17]["fg_color"],
                command=self.button_configs[17]["command"],
                hover_color=self.button_configs[17]["hover_color"],
                text_color=self.button_configs[17]["text_color"],
                font=self.button_configs[17]["font"])
            button.grid(row=3, column=2, sticky="nsew", padx=4, pady=4)

            self.button_configs[18]["text"] = "tan⁻¹(x)"
            self.button_configs[18]["command"] = lambda: self.on_button_click("arctan(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[18]["text"],
                fg_color=self.button_configs[18]["fg_color"],
                command=self.button_configs[18]["command"],
                hover_color=self.button_configs[18]["hover_color"],
                text_color=self.button_configs[18]["text_color"],
                font=self.button_configs[18]["font"])
            button.grid(row=3, column=3, sticky="nsew", padx=4, pady=4)

            self.button_configs[2]["command"] = lambda: self.on_button_click("integral")
            self.button_configs[2]["text"] = "ʃdx"
            self.button_configs[2]["font"] = ("Helvetica", 18, "bold")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[2]["text"],
                fg_color=self.button_configs[2]["fg_color"],
                command=self.button_configs[2]["command"],
                hover_color=self.button_configs[2]["hover_color"],
                text_color=self.button_configs[2]["text_color"],
                font=self.button_configs[2]["font"])
            button.grid(row=0, column=2, sticky="nsew", padx=4, pady=4)
            
            self.button_configs[23]["text"] = "X"
            self.button_configs[23]["command"] = lambda: self.on_button_click("x")
            self.button_configs[23]["fg_color"] = self.verde
            self.button_configs[23]["hover_color"] = self.verde_hover
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[23]["text"],
                fg_color=self.button_configs[23]["fg_color"],
                command=self.button_configs[23]["command"],
                hover_color=self.button_configs[23]["hover_color"],
                text_color=self.button_configs[23]["text_color"],
                font=self.button_configs[23]["font"])
            button.grid(row=4, column=3, sticky="nsew", padx=4, pady=4)

            self.button_configs[9]["text"] = "Logₐ(x)"
            self.button_configs[9]["command"] = lambda: self.on_button_click("loga(x)")
            button = ctk.CTkButton(
                self.frame_botones_calculadora,
                width=5,
                text=self.button_configs[9]["text"],
                fg_color=self.button_configs[9]["fg_color"],
                command=self.button_configs[9]["command"],
                hover_color=self.button_configs[9]["hover_color"],
                text_color=self.button_configs[9]["text_color"],
                font=self.button_configs[9]["font"])
            button.grid(row=1, column=4, sticky="nsew", padx=4, pady=4)

    def apply_factorial(self):
        self.wrap_term_and_apply("!")

    def apply_power(self, power):
        self.wrap_term_and_apply(f"**{power}")

    def wrap_term_and_apply(self, operator):
        content = self.entry_calculadora.get()
        pos = self.entry_calculadora.index(tk.INSERT)
        left_part = content[:pos]

        # Regex to find the last "complete term" before the cursor
        match = re.search(r"([A-Za-z0-9.]+)$", left_part)
        if match:
            start = match.start()
            term = match.group(0)
            new_content = content[:start] + f"({term}){operator}" + content[pos:]
        else:
            new_content = content + f"({operator})"

        self.entry_calculadora.delete(0, tk.END)
        self.entry_calculadora.insert(0, new_content)

    def find_closing_parenthesis(self, s, open_pos):
        stack = []
        for i in range(open_pos, len(s)):
            if s[i] == '(':
                stack.append('(')
            elif s[i] == ')':
                if stack:
                    stack.pop()
                if not stack:
                    return i
        return -1

    def find_opening_parenthesis(self, s, open_pos):
        for i in range(open_pos, len(s)):
            if s[i] == '(':
                return i + 1
        
    def insert_character(self, character):
        self.entry_calculadora.focus_set()
        cursor_pos = self.entry_calculadora.index(tk.INSERT)
        self.entry_calculadora.insert(cursor_pos, character)

    def borrar_caracter(self):
        index = self.entry_calculadora.index(tk.INSERT)
        str_len = len(self.entry_calculadora.get())
        focused_widget = self.frame_superior_calculadora.focus_get()
        entry_widget = self.entry_calculadora
        # Recorrer hacia arriba en la jerarquía de widgets para ver si el `CTkEntry` es un ancestro del widget con foco
        while focused_widget is not None:
            if focused_widget == entry_widget:
                # Si el widget con foco es `CTkEntry` o uno de sus subcomponentes internos
                self.entry_calculadora.delete(index-1, index)
                break
            focused_widget = focused_widget.master

        if focused_widget is None:
            # Si el foco no está en el `CTkEntry` o sus subcomponentes, eliminar el último caracter
            self.entry_calculadora.delete(str_len-1, str_len)

class FourierSeries(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.grid(sticky="nsew")  # Asegura que el frame ocupe el espacio asignado en el grid
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=5)
        self.rowconfigure(0, weight=1)
        self.par_mode = False

        self.onda_cuadrada_active = True
        self.onda_triangular_active = False
        
        self.function_dict = {
            'sin': 'np.sin',
            'cos': 'np.cos',
            'tan': 'np.tan',
            'log': 'np.log',
            'exp': 'np.exp',
            'sqrt': 'np.sqrt',
            'Γ': 'gamma', 
            'sinh': 'np.sinh',
            'cosh': 'np.cosh',
            'tanh': 'np.tanh',
            'arcsin': 'np.arcsin',
            'arccos': 'np.arccos',
            'arctan': 'np.arctan',
            'arcsinh': 'np.arcsinh',
            'arccosh': 'np.arccosh',
            'arctanh': 'np.arctanh',
            'π': 'np.pi',
            'pi': 'np.pi',
            'e': 'np.e'
        }
        
        style = ttk.Style()
        style.configure("CustomCheckbutton.TCheckbutton", background="#8c8c8c", font=("Helvetica", 11), foreground="#fff", focus_outline = "none")

        self.create_widgets()
    
    def create_widgets(self):
        #frame barra izquierda_______________________________________________________________
        # Frame para las entradas y parámetros
        self.frame_barra_izquierda = tk.Frame(self, bg="#f00", width=300)
        self.frame_barra_izquierda.grid_propagate(False)  # No permitir que el frame cambie de tamaño
        self.frame_barra_izquierda.rowconfigure(0, weight=1)
        self.frame_barra_izquierda.rowconfigure(1, weight=10)
        self.frame_barra_izquierda.columnconfigure(0, weight=1)
        self.frame_barra_izquierda.grid(row=0, column=0, sticky="nsew")

        # Frame modo superior
        self.frame_modo_superior = tk.Frame(self.frame_barra_izquierda)
        self.frame_modo_superior.columnconfigure(0, weight=1)
        self.frame_modo_superior.rowconfigure(0, weight=1)
        self.frame_modo_superior.rowconfigure(1, weight=1)
        self.frame_modo_superior.grid(column=0, row=0, sticky="nsew")

        self.label_titulo = ctk.CTkLabel(self.frame_modo_superior, pady=5, text="Graficadora de serie y transformada de Fourier", width=30, font=("Helvetica", 16, "bold"), text_color="#fff", fg_color=("#B4941A", "#B4941A"))
        self.label_titulo.grid(column=0, row=0, sticky="nsew")

        # Frame modo superior
        self.frame_buttons_modo_superior = tk.Frame(self.frame_modo_superior, bg="#8c8c8c")
        self.frame_buttons_modo_superior.columnconfigure(0, weight=1)
        self.frame_buttons_modo_superior.columnconfigure(1, weight=1)
        self.frame_buttons_modo_superior.columnconfigure(2, weight=1)
        self.frame_buttons_modo_superior.rowconfigure(0, weight=1)
        self.frame_buttons_modo_superior.rowconfigure(1, weight=1)
        self.frame_buttons_modo_superior.grid(column=0, row=1, sticky="nsew")

        self.entry_a0 = ctk.CTkEntry(self.frame_buttons_modo_superior, width=80, height=20, placeholder_text="A0 = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color=("#ccc", "#ccc"), state="normal")
        self.entry_a0.grid(column=0, row=0, pady=10, padx=2)

        self.entry_an = ctk.CTkEntry(self.frame_buttons_modo_superior, width=80, height=20, placeholder_text="An = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color=("#ccc", "#ccc"), state="normal")
        self.entry_an.grid(column=0, row=1, pady=10, padx=2)

        self.entry_bn = ctk.CTkEntry(self.frame_buttons_modo_superior, width=80, height=20, placeholder_text="Bn = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color=("#ccc", "#ccc"), state="normal")
        self.entry_bn.grid(column=0, row=2, pady=10, padx=2)

        self.label = ctk.CTkLabel(self.frame_buttons_modo_superior, text="N° Terminos: ", pady=5, width=30, font=("Helvetica", 16, "bold"), text_color="#fff")
        self.label.grid(column=1, row=0, pady=5, padx=5)

        self.my_slider = ctk.CTkSlider(self.frame_buttons_modo_superior, number_of_steps=49, height=10, from_=1, to=50, command=self.write, fg_color="#fff", progress_color="#fff", button_color="#1d1d1d", button_hover_color="#1c1c1c")
        self.my_slider.set(10)
        self.my_slider.grid(column=1, row=1)

        # Frame interno
        self.frame_min_max_buttons = tk.Frame(self.frame_buttons_modo_superior, bg="#8c8c8c")
        self.frame_min_max_buttons.grid(column=1, row=2)

        self.entry_tmin = ctk.CTkEntry(self.frame_min_max_buttons, width=75, height=20, placeholder_text="Tmin = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color="#ccc", state="normal")
        self.entry_tmin.grid(column=0, row=0, padx=5)

        self.entry_tmax = ctk.CTkEntry(self.frame_min_max_buttons, width=75, height=20, placeholder_text="Tmax = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color="#ccc", state="normal")
        self.entry_tmax.grid(column=1, row=0, padx=5)

        self.entry_period = ctk.CTkEntry(self.frame_min_max_buttons, width=75, height=20, placeholder_text="T = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color=("#ccc", "#ccc"), state="normal")
        self.entry_period.grid(column=2, row=0, padx=2)

        self.button_graph = ctk.CTkButton(self.frame_buttons_modo_superior, command=self.calculate_expression, width=60, height=50, text="Graficar", text_color="#fff", corner_radius=5, fg_color="#B4941A", hover_color="#A28309")
        self.button_graph.grid(column=2, row=0, padx=5, pady=5)

        self.checkbox_var = tk.BooleanVar()
        self.entry_summation = ttk.Checkbutton(self.frame_buttons_modo_superior,style="CustomCheckbutton.TCheckbutton", text="N par", variable=self.checkbox_var, command=self.par)
        self.entry_summation.grid(column=2, row=1, padx=5, pady=5)


        self.button_graph = ctk.CTkButton(self.frame_buttons_modo_superior, command=self.limpiar_grafica, width=60, height=50, text="Limpiar", text_color="#fff", corner_radius=5, fg_color="#B4941A", hover_color="#A28309")
        self.button_graph.grid(column=2, row=2, padx=5, pady=5)
        
        self.button_gif = ctk.CTkButton(self.frame_buttons_modo_superior, command=self.generate_animations, width=200, height=50, text="Mostrar animacion", text_color="#fff", corner_radius=5, fg_color="#B4941A", hover_color="#A28309")
        self.button_gif.grid(column=0, row=3, columnspan = 3, padx=5, pady=20)

        # Frame canvas
        self.frame_canvas_modo_superior = tk.Frame(self.frame_modo_superior, bg="#000", height=100)
        self.frame_canvas_modo_superior.grid(column=0, row=2, sticky="ew")
        self.frame_canvas_modo_superior.grid_propagate(False)  # Mantener el tamaño fijo

        self.scroll_x = tk.Scrollbar(self.frame_canvas_modo_superior, orient="horizontal")
        self.scroll_x.pack(side="bottom", fill="x")
        self.scroll_x.set(0.5, 0.55)

        self.canvas = tk.Canvas(self.frame_canvas_modo_superior, bg="#ffffff", height=100, xscrollcommand=self.scroll_x.set)
        self.canvas.pack(side="top", fill="both", expand=True)

        self.scroll_x.configure(command=self.canvas.xview)

        # Inicializar con la expresión fija "f(t) ="
        self.render_latex_expression("f(t) = ")




        #Frame modo inferior_____________________________________________________________
        self.frame_modo_inferior = tk.Frame(self.frame_barra_izquierda, bg = "#8c8c8c")
        self.frame_modo_inferior.columnconfigure(0, weight=1)
        self.frame_modo_inferior.grid(column=0, row=1, sticky="nsew")


        label_funciones = ctk.CTkLabel(self.frame_modo_inferior, text="Funciones:", pady = 10, bg_color="#B4941A", text_color="#fff", font=("Helvetica", 18))
        label_funciones.grid(column = 0, row = 0, sticky = "ew")
        options = ["Señal cuadrada", "Señal triangular"]
        option_menu = ctk.CTkOptionMenu(self.frame_modo_inferior, font = ("Helvetica", 16), state = "normal", anchor="center", hover=True, dynamic_resizing = True, values=options, command=self.option_selected, fg_color= "#4c4c4c",dropdown_fg_color= "#2c2c2c", button_color="#4c4c4c", button_hover_color="#2c2c2c", corner_radius=0, dropdown_hover_color= "#1c1c1c" ,dropdown_text_color="#fff", dropdown_font=("Helvetica", 16))
        option_menu.grid(column = 0, row = 1, sticky = "ew")


        
        self.frame_modo_inferior_buttons = tk.Frame(self.frame_modo_inferior, bg="#8c8c8c")
    
        self.frame_modo_inferior_buttons.columnconfigure(0, weight=1)
        self.frame_modo_inferior_buttons.columnconfigure(1, weight=1)
        self.frame_modo_inferior_buttons.grid(column = 0, row = 2, sticky= "nsew")



        self.entry_amplitude = ctk.CTkEntry(self.frame_modo_inferior_buttons, width=100, height=20, placeholder_text="Amplitud =  ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color="#ccc", state="normal")
        self.entry_amplitude.grid(column=0, row=0, pady = 15, padx = 10)

        self.entry_period2 = ctk.CTkEntry(self.frame_modo_inferior_buttons, width=100, height=20, placeholder_text="T = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color=("#ccc", "#ccc"), state="normal")
        self.entry_period2.grid(column=0, row=1, pady = 15, padx = 10)

        self.button_graph = ctk.CTkButton(self.frame_modo_inferior_buttons, command=self.calculate_expression2, width=100, height=50, text="Graficar", text_color="#fff", corner_radius=5, fg_color="#B4941A", hover_color="#A28309")
        self.button_graph.grid(column=0, row=2, padx=5, pady=5)

        self.label_terminos2 = ctk.CTkLabel(self.frame_modo_inferior_buttons, text="N° Terminos: ", pady=5, width=30, font=("Helvetica", 16, "bold"), text_color="#fff")
        self.label_terminos2.grid(column=1, row=0, pady = 15, padx = 10)

        self.my_slider2 = ctk.CTkSlider(self.frame_modo_inferior_buttons, number_of_steps=49, height=10, from_=1, to=50, command=self.write2, fg_color="#fff", progress_color="#fff", button_color="#1d1d1d", button_hover_color="#1c1c1c")
        self.my_slider2.set(10)
        self.my_slider2.grid(column=1, row=1, pady = 15, padx = 10)

        self.frame_min_max_buttons_inferior = tk.Frame(self.frame_modo_inferior_buttons, bg="#8c8c8c")
        self.frame_min_max_buttons_inferior.grid(column=1, row=2)

        self.entry_tmin2 = ctk.CTkEntry(self.frame_min_max_buttons_inferior, width=100, height=30, placeholder_text="Tmin = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color="#ccc", state="normal")
        self.entry_tmin2.grid(column=0, row=0, padx=5)

        self.entry_tmax2 = ctk.CTkEntry(self.frame_min_max_buttons_inferior, width=100, height=30, placeholder_text="Tmax = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color="#ccc", state="normal")
        self.entry_tmax2.grid(column=1, row=0, padx=5)

        self.entry_a0_2 = ctk.CTkEntry(self.frame_min_max_buttons_inferior, width=100, height=30, placeholder_text="A0 = ", font=("Helvetica", 15), text_color="black", corner_radius=5, border_color="#111", border_width=2, placeholder_text_color="black", fg_color="#ccc", state="normal")
        self.entry_a0_2.grid(column=2, row=0, padx=5)







        #frame representaciones_______________________________________________________
        self.frame_representaciones = tk.Frame(self, bg="#0f0")
        self.frame_representaciones.rowconfigure(0, weight = 1)
        self.frame_representaciones.rowconfigure(1, weight = 1)
        self.frame_representaciones.columnconfigure(0, weight = 1)
        self.frame_representaciones.grid(column = 1, row = 0, sticky="nsew")
        # self.frame_representaciones.grid_propagate(False)
        
        
        #Frame serie y transformada:_______________________________________________________
        self.frame_grafica_transformada_serie = tk.Frame(self.frame_representaciones, bg ="blue")
        self.frame_grafica_transformada_serie.columnconfigure(0, weight = 1)
        self.frame_grafica_transformada_serie.columnconfigure(1, weight = 1)
        self.frame_grafica_transformada_serie.rowconfigure(0, weight = 1)
        self.frame_grafica_transformada_serie.grid(column = 0, row = 0, sticky="nsew")


        # Frame grafica serie Fourier:_______________________________________________________
        self.frame_grafica_serie_fourier = tk.Frame(self.frame_grafica_transformada_serie, bg="#00f")
        self.frame_grafica_serie_fourier.rowconfigure(0, weight=1)
        self.frame_grafica_serie_fourier.columnconfigure(0, weight=1)
        self.frame_grafica_serie_fourier.grid(column=0, row=0, sticky="nsew")

        self.fig, self.ax = plt.subplots(figsize=(0.5, 0.5))  # Ajusta el tamaño del gráfico aquí
        self.ax.grid(True)
        self.ax.set_title('Serie de Fourier')
        self.canvas_serie_fourier = FigureCanvasTkAgg(self.fig, master=self.frame_grafica_serie_fourier)
        self.canvas_serie_fourier.draw()
        self.canvas_serie_fourier.get_tk_widget().grid(column=0, row=0, sticky="nsew")

        # Frame transformada Fourier:_______________________________________________________
        self.frame_grafica_transformada = tk.Frame(self.frame_grafica_transformada_serie, bg="#0ff")
        self.frame_grafica_transformada.rowconfigure(0, weight=1)
        self.frame_grafica_transformada.columnconfigure(0, weight=1)
        self.frame_grafica_transformada.grid(column=1, row=0, sticky="nsew")

        self.fig2, self.ax2 = plt.subplots(figsize=(0.5, 0.5))  # Ajusta el tamaño del gráfico aquí
        self.ax2.grid(True)
        self.ax2.set_title('Transformada de Fourier')
        self.canvas_transformada_fourier = FigureCanvasTkAgg(self.fig2, master=self.frame_grafica_transformada)
        self.canvas_transformada_fourier.draw()
        self.canvas_transformada_fourier.get_tk_widget().grid(column=0, row=0, sticky="nsew")




        #Frame GIF Fourier:_______________________________________________________
        self.frame_gif_fourier = tk.Frame(self.frame_representaciones, bg="#f0f")
        self.frame_gif_fourier.rowconfigure(0, weight = 1)
        self.frame_gif_fourier.columnconfigure(0, weight = 1)
        self.frame_gif_fourier.columnconfigure(1, weight = 1)
        self.frame_gif_fourier.grid(column = 0, row = 1, sticky="nsew")

        self.frame_animation_1 = tk.Frame(self.frame_gif_fourier, bg="black")
        self.frame_animation_1.rowconfigure(0, weight=1)
        self.frame_animation_1.columnconfigure(0, weight=1)
        self.frame_animation_1.grid(column = 0, row = 0, sticky = "nsew")
        self.frame_animation_1.grid_propagate(False)

        self.frame_animation_2 = tk.Frame(self.frame_gif_fourier, bg="white")
        self.frame_animation_2.rowconfigure(0, weight=1)
        self.frame_animation_2.columnconfigure(0, weight=1)
        self.frame_animation_2.grid(column = 1, row = 0, sticky = "nsew")
        self.frame_animation_2.grid_propagate(False)


    def calculate_expression2(self):
        amplitude = self.entry_amplitude.get()
        period = self.entry_period2.get()
        tmin = self.entry_tmin2.get()
        tmax = self.entry_tmax2.get()
        n_terms = int(self.my_slider2.get())
        a_0 = self.entry_a0_2.get()

        try:
            amplitude = float(amplitude) if amplitude else 1
            tmin = float(tmin) if tmin else -2 * np.pi
            tmax = float(tmax) if tmax else 2 * np.pi
            T = float(eval(self.preprocess_input(period))) if period else 2 * np.pi
            T_latex = period or "2\\pi"
            a_0 = self.preprocess_input(a_0 or "0")
        except Exception as e:
            messagebox.showerror("Error", "Introduce valores correctos!")
            return

        a_0_latex = f"{a_0} + " if a_0 != "0" else ""

        
        if self.onda_cuadrada_active:
            an_term = "0"  # No hay términos an para la onda cuadrada
            bn_term = self.preprocess_input(f"4*{amplitude}/pi * (1/(n))" or "0")
            bn_latex = f"\\frac{{4\\cdot {amplitude}}}{{\\pi}} \\cdot \\frac{{1}}{{2n-1}}"
            latex_expr = (
                f"f(t) = {a_0_latex}\\sum_{{n=1}}^{{{n_terms}}} \\left( {bn_latex} \\sin\\left(\\frac{{2\\pi (2n-1) t}}{{{T_latex}}}\\right) \\right)"
            )
        elif self.onda_triangular_active:
            an_term = self.preprocess_input(f"8*{amplitude}/((pi)**2) * (1 / (n)**2)")
            bn_term = "0"  # No hay términos bn para la onda triangular
            an_latex = f"\\frac{{8\\cdot {amplitude}}}{{\\pi^2}} \\cdot \\frac{{(-1)^{{n-1}}}}{{(2n-1)^2}}"
            latex_expr = (
                f"f(t) = {a_0_latex}\\sum_{{n=1}}^{{{n_terms}}} \\left( {an_latex} \\cos\\left(\\frac{{2\\pi (2n-1) t}}{{{T_latex}}}\\right) \\right)"
            )
        
        fourier_series = f"{a_0}"
        

        for n in range(1, n_terms + 1):
            n_value = 2 * n if self.par_mode else 2 * n - 1

            current_an_term = re.sub(r'\bn\b', str(n_value), an_term)
            current_bn_term = re.sub(r'\bn\b', str(n_value), bn_term)
            
            # Optimización para omitir términos cuando an o bn son 0
            if an_term != "0":
                fourier_series += f" + ({current_an_term} * np.cos(2 * np.pi * {n_value} * t / {T}))"
            if bn_term != "0":
                fourier_series += f" + ({current_bn_term} * np.sin(2 * np.pi * {n_value} * t / {T}))"
        
        self.render_latex_expression(latex_expr)
        self.plot_fourier_series(fourier_series, tmin, tmax)
        self.plot_fourier_transform(fourier_series, tmin, tmax)

    def show_gif(self):
        pass

    def option_selected(self, choice):
        if choice == "Señal cuadrada":
            self.onda_cuadrada_active = True
            self.onda_triangular_active = False
        elif choice == "Señal triangular":
            self.onda_triangular_active = True
            self.onda_cuadrada_active = False

        

    def calculate_expression(self):
        an_coefficient = self.entry_an.get()
        bn_coefficient = self.entry_bn.get()
        n_terms = int(self.my_slider.get())
        period = self.entry_period.get()
        a_0 = self.entry_a0.get() or "0"  # Default to 0 if no value is provided

        try:
            tmin = float(self.entry_tmin.get()) if self.entry_tmin.get() else -2 * np.pi
            tmax = float(self.entry_tmax.get()) if self.entry_tmax.get() else 2 * np.pi
            T = float(eval(self.preprocess_input(period))) if period else 2 * np.pi
            T_latex = period or "2*pi"
        except Exception as e:
            messagebox.showerror("Error", "Introduce valores correctos!")
            return

        try:
            a0_term = self.preprocess_input(a_0 or "0")
            an_term = self.preprocess_input(an_coefficient or "0")  # Default to 0 if no value is provided
            bn_term = self.preprocess_input(bn_coefficient or "0")  # Default to 0 if no value is provided
        except Exception as e:
            messagebox.showerror("Error", "Introduce un A0, An, Bn validos!")
            return


        a_0_latex = f"{a_0} + " if a0_term != "0" else ""
        a_n_latex = f"{an_coefficient} \\cos\\left(\\frac{{2\\pi n t}}{{{T_latex}}}\\right) + "  if an_term != "0" else ""
        b_n_latex = f"{bn_coefficient} \\sin\\left(\\frac{{2\\pi n t}}{{{T_latex}}}\\right) \\right)" if bn_term != "0" else ""
        
        latex_expr = (
            f"f(t) = {a_0_latex}\\sum_{{n=1}}^{{{n_terms}}} \\left( "
            f"{a_n_latex}"
            f"{b_n_latex}"
        )

        fourier_series = f"{a0_term}"

        for n in range(1, n_terms + 1):
            n_value = 2 * n if self.par_mode else 2 * n - 1
            current_an_term = re.sub(r'\bn\b', str(n_value), an_term)
            current_bn_term = re.sub(r'\bn\b', str(n_value), bn_term)
            
            # Optimización para omitir términos cuando an o bn son 0
            if an_term != "0":
                fourier_series += f" + ({current_an_term} * np.cos(2 * np.pi * {n_value} * t / {T}))"
            if bn_term != "0":
                fourier_series += f" + ({current_bn_term} * np.sin(2 * np.pi * {n_value} * t / {T}))"
        
        self.render_latex_expression(latex_expr)
        self.plot_fourier_series(fourier_series, tmin, tmax)
        self.plot_fourier_transform(fourier_series, tmin, tmax)

    def plot_fourier_series(self, series, tmin, tmax):
        messagebox.showerror("1", series)
        if self.canvas_serie_fourier is None:
            self.canvas_serie_fourier = self.ax.figure.canvas


        t = np.linspace(tmin, tmax, 400)
        y = eval(series)
        self.ax.clear()
        self.ax.grid(True)
        self.ax.set_title('Serie de Fourier')
        line, = self.ax.plot(t, y, label=series)
        self.canvas_serie_fourier.draw()

    def plot_fourier_transform(self, fourier_series, tmin, tmax):
        # Definir la función para el cálculo de la transformada de Fourier
        def f(t):
            return eval(fourier_series)

        # Crear un vector de tiempo y calcular los valores de la serie
        t = np.linspace(tmin, tmax, 1000)
        y = f(t)

        # Calcular la transformada de Fourier
        Y = np.fft.fft(y)
        freq = np.fft.fftfreq(len(t), d=(t[1]-t[0]))


        self.ax2.clear()
        self.ax2.grid(True)
        self.ax2.set_title('Transformada de Fourier')
        self.ax2.set_xlim(-tmin , tmin )
        self.ax2.set_ylim(0, 50)
        line, = self.ax2.plot(freq, np.abs(Y), label="transform")
        self.canvas_transformada_fourier.draw()

    def display_plot(self, figure, frame):
        canvas = FigureCanvasTkAgg(figure, master=frame)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

        toolbar = NavigationToolbar2Tk(canvas, frame)
        toolbar.update()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

    def render_latex_expression(self, latex_expr):
        fig, ax = plt.subplots(figsize=(10, 2))  # Tamaño de la figura ajustado
        ax.text(0.5, 0.8, f"${latex_expr}$", horizontalalignment='center', verticalalignment='center', fontsize=12)
        ax.axis('off')

        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)

        img = Image.open(buf)
        img_tk = ImageTk.PhotoImage(img)

        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor="nw", image=img_tk)
        self.canvas.image = img_tk 
        self.canvas.config(scrollregion=self.canvas.bbox("all"))

    def update_expression(self, value):
        self.write(value)
        self.calculate_expression()

    def write(self, value):
        self.label.configure(text=f"N° Terminos: {int(value)}")

    def write2(self, value):
        self.label_terminos2.configure(text=f"N° Terminos: {int(value)}")

    def par(self):
        self.par_mode  = self.checkbox_var.get()

    def limpiar_grafica(self):
        self.ax.clear()
        self.ax2.clear()
        self.ax.grid(True)
        self.ax.set_title('Serie de Fourier')
        self.ax2.grid(True)
        self.ax2.set_title('Transformada de Fourier')
        self.ax.figure.canvas.draw()
        self.ax2.figure.canvas.draw()

    def update_plot(self):
        self.canvas.draw()

    def preprocess_input(self, raw_function):
        for key in sorted(self.function_dict, key=len, reverse=True):
            pattern = r'\b' + re.escape(key) + r'\b'  # \b indica un límite de palabra
            raw_function = re.sub(pattern, self.function_dict[key], raw_function)
        return raw_function

    def fourier_series(self, t, n_terms, a0_term, an_term, bn_term, T):
        result = np.zeros_like(t)
        result += eval(f"{a0_term}")
        for n in range(1, n_terms + 1):
            n_value = 2 * n if self.par_mode else 2 * n - 1
            current_an_term = re.sub(r'\bn\b', str(n_value), an_term)
            current_bn_term = re.sub(r'\bn\b', str(n_value), bn_term)
            # Optimización para omitir términos cuando an o bn son 0
            if an_term != "0":
                result += eval(f" + ({current_an_term} * np.cos(2 * np.pi * {n_value} * t / {T}))")
            if bn_term != "0":
                result += eval(f" + ({current_bn_term} * np.sin(2 * np.pi * {n_value} * t / {T}))")
    
        return result


    def generate_animation(self):
        an_coefficient = self.entry_an.get()
        bn_coefficient = self.entry_bn.get()
        n_terms = int(self.my_slider.get())
        period = self.entry_period.get()
        a_0 = self.entry_a0.get() or "0"  # Default to 0 if no value is provided

        try:
            tmin = float(self.entry_tmin.get()) if self.entry_tmin.get() else -2 * np.pi
            tmax = float(self.entry_tmax.get()) if self.entry_tmax.get() else 2 * np.pi
            T = float(eval(self.preprocess_input(period))) if period else 2 * np.pi
        except Exception as e:
            messagebox.showerror("Error", "Introduce valores correctos!")
            return

        try:
            a0_term = self.preprocess_input(a_0 or "0")
            an_term = self.preprocess_input(an_coefficient or "0")  # Default to 0 if no value is provided
            bn_term = self.preprocess_input(bn_coefficient or "0")  # Default to 0 if no value is provided
        except Exception as e:
            messagebox.showerror("Error", "Introduce un A0, An, Bn validos!")
            return

        num_frames = 50  # Número de cuadros en la animación
        num_terms_max = 50  # Número máximo de términos de la serie
        # Crear la figura y los ejes de Matplotlib
        fig, ax3 = plt.subplots(figsize=(3.5, 3.5))
        ax3.set_xlim(tmin, tmax)
        ax3.grid(True)
        images = []

        for i in range(1, num_frames + 1):
            t = np.linspace(tmin, tmax, 400)
            for n in range(1, i + 1):
                ax3.plot(t, self.fourier_series(t, n, a0_term, an_term, bn_term, T))
            ax3.set_title(f"N° términos: {i}")
            ax3.legend(loc="upper right")

            # Guardar la imagen actual
            filename = f"frame_{i:03d}.png"
            plt.savefig(filename)
            images.append(filename)
        
        # Crear el GIF a partir de las imágenes generadas
        with imageio.get_writer('fourier_series_1.gif', mode='I') as writer:
            for filename in images:
                image = imageio.imread(filename)
                writer.append_data(image)

        # Eliminar las imágenes temporales
        for filename in set(images):
            os.remove(filename)

        messagebox.showinfo("Información", "GIF1 generado con éxito.")
        self.play_gif("fourier_series_1.gif", True)

    def generate_animations(self):
        self.generate_animation()
        self.generate_animation2()

    def generate_animation2(self):
        an_coefficient = self.entry_an.get()
        bn_coefficient = self.entry_bn.get()
        period = self.entry_period.get()
        a_0 = self.entry_a0.get() or "0"  # Default to 0 if no value is provided

        try:
            tmin = float(self.entry_tmin.get()) if self.entry_tmin.get() else -2 * np.pi
            tmax = float(self.entry_tmax.get()) if self.entry_tmax.get() else 2 * np.pi
            T = float(eval(self.preprocess_input(period))) if period else 2 * np.pi
        except Exception as e:
            messagebox.showerror("Error", "Introduce valores correctos!")
            return

        try:
            a0_term = self.preprocess_input(a_0 or "0")
            an_term = self.preprocess_input(an_coefficient or "0")  # Default to 0 if no value is provided
            bn_term = self.preprocess_input(bn_coefficient or "0")  # Default to 0 if no value is provided
        except Exception as e:
            messagebox.showerror("Error", "Introduce un A0, An, Bn validos!")
            return
        
        num_frames = 50  # Número de cuadros en la animación
        num_terms_max = 50  # Número máximo de términos de la serie
        
        fig, ax4 = plt.subplots(figsize=(3.5, 3.5))
        ax4.set_xlim(tmin, tmax)
        ax4.grid(True)
        
        images = []
        for i in range(1, num_frames + 1):
            ax4.clear()
            ax4.set_xlim(tmin, tmax)
            ax4.grid(True)
            
            num_terms = int(i / num_frames * num_terms_max)  # Número de términos en esta iteración
            t = np.linspace(tmin, tmax, 400)
            y = self.fourier_series(t, num_terms, a0_term, an_term, bn_term, T)

            ax4.plot(t, y)
            ax4.set_title(f"N° términos: {i}")
            ax4.legend(loc="upper right")
            
            filename = f"frame_{i:03d}.png"
            fig.savefig(filename)
            
            images.append(filename)
        
        plt.close(fig)

        with imageio.get_writer('fourier_series_2.gif', mode='I') as writer:
            for filename in images:
                image = imageio.imread(filename)
                writer.append_data(image)

        for filename in set(images):
            os.remove(filename)

        messagebox.showinfo("Información", "GIF2 generado con éxito.")
        self.play_gif("fourier_series_2.gif", False)


    def play_gif(self, gif_path, animation1):
        def update_image(idx):
            frame = frames[idx]
            img = ImageTk.PhotoImage(frame)
            label.config(image=img)
            label.image = img
            idx += 1
            if idx == len(frames):
                idx = 0  # Reiniciar la reproducción al final del GIF
            label.after(100, update_image, idx)  # Llamar a la función nuevamente después de 100 ms

        if animation1:
            label = tk.Label(self.frame_animation_1, width=self.frame_animation_1.winfo_width(), height=self.frame_animation_1.winfo_height())
            label.grid(column=0, row=0, sticky="nsew")
        else:
            label = tk.Label(self.frame_animation_2, width=self.frame_animation_2.winfo_width(), height=self.frame_animation_2.winfo_height())
            label.grid(column=1, row=0, sticky="nsew")

        gif = Image.open(gif_path)
        frames = [frame.copy() for frame in ImageSequence.Iterator(gif)]
        update_image(0)
        
class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Multi-function Calculator")
        self.geometry(screen_size)
        self.current_mode = 2
        image_icon_calculator = Image.open(icon_calculator_address) 
        photo_icon_calculator = ImageTk.PhotoImage(image_icon_calculator)
        self.iconphoto(False, photo_icon_calculator)

        img_calculator2 = Image.open(icon_calculator2_address)
        img_calculator2 = img_calculator2.resize((32,  int((float(img_calculator2.size[1]) * float((32 / float(img_calculator2.size[0])))))))
        self.photo_calculator2 = ImageTk.PhotoImage(img_calculator2)


        img_graph = Image.open(graph_address)
        img_graph = img_graph.resize((50,  int((float(img_graph.size[1]) * float((50 / float(img_graph.size[0])))))))
        self.photo_graph = ImageTk.PhotoImage(img_graph)

        self.main_frame = tk.Frame(self)
        self.main_frame.pack(fill='both', expand=True)

        self.main_frame.columnconfigure(1, weight=1) 
        self.main_frame.rowconfigure(0, weight=1)     

        # Widgets de la aplicación
        self.graphical_calculator = GraphicalCalculator(self.main_frame)
        self.basic_calculator = BasicCalculator(self.main_frame)
        self.fourier_frame = FourierSeries(self.main_frame)

        self.mode_selection_frame = tk.Frame(self.main_frame, bg="#2f2f2f")
        self.mode_selection_frame.grid(column=0, row=0, sticky="ns")

        # Contenido de la barra lateral utilizando grid
        button1 = ctk.CTkButton(self.mode_selection_frame, image=self.photo_graph, width=30 ,height=60, command=self.Funciones_grafica, fg_color=barra_izquierda, text="", hover_color= gris_oscuro_barra_izquierda)
        button1.grid(row=0, column=0, pady=5, padx=3, sticky = "nsew")

        button2 = ctk.CTkButton(self.mode_selection_frame,text="Four(y)", command=self.Fourier_grafica, width=30 ,height=60, font=("Helvetica", 16), text_color="#000", fg_color=barra_izquierda, hover_color= gris_oscuro_barra_izquierda)
        button2.grid(row=1, column=0, pady=5, padx=3, sticky = "nsew")

        button3 = ctk.CTkButton(self.mode_selection_frame, image=self.photo_calculator2 , width=30 ,height=60, command=self.Calculadora_grafica, fg_color=barra_izquierda, hover_color= gris_oscuro_barra_izquierda, text="")
        button3.grid(row=2, column=0, pady=5, padx=3, sticky = "nsew")


        self.mode_selection_frame.columnconfigure(0, weight=1)
        self.Funciones_grafica()  # Mostrar inicialmente la calculadora básica

    def Calculadora_grafica(self):
        self.fourier_frame.grid_forget()
        self.graphical_calculator.grid_forget()
        
        self.current_mode = 0
        self.basic_calculator.grid(column=1, row=0, sticky="nsew")

    def Fourier_grafica(self):
        self.basic_calculator.grid_forget()
        self.graphical_calculator.grid_forget()
        
        self.current_mode = 1
        self.fourier_frame.grid(column = 1, row = 0, sticky = "nsew")

    def Funciones_grafica(self):
        self.basic_calculator.grid_forget()
        self.fourier_frame.grid_forget()
        
        self.current_mode = 2
        self.graphical_calculator.grid(column = 1, row = 0, sticky = "nsew")

if __name__ == "__main__":
    app = App()
    app.mainloop()